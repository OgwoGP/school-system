﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ES School ERP System")> 
<Assembly: AssemblyDescription("Warning: Please do not distribute this computer program without permission of its owner. Unauthorized reproduction or distribution of this program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted under the maximum extent possible under law.")>
<Assembly: AssemblyCompany("Developed By : E-Solutions PK")> 
<Assembly: AssemblyProduct("ES School ERP System")> 
<Assembly: AssemblyCopyright("Copyright ©  2018-2019")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("77de0390-f9d0-4c6c-a848-11ef1a344edb")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("5.2.1.0")> 
<Assembly: AssemblyFileVersion("5.2.1.0")> 
