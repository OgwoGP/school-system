﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MasterEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HouseInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SessionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FeeInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstallmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusFeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelFeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiscountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BranchMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SemesterMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DocumentMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AtteandanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelerMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusHoldersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PromotionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InactiveEntryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IdentityCardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentMasterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesignationMasterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusHoldersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubjectMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExamTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExamEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GradeMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarksEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarksheetLedgerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PayrollToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesignationMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdvanceEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AtteanceEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LibraryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksClassificationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubCategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewspaperMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JournalsAndMagazinesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewspaperEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookIssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksReservationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuotationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusFeePaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassFeePaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelFeePaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpenseMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpensesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoucherToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseDaybookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DaybookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneralLedgerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierLedgerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrialBalanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsersRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SMSSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmailSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SQLServerSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportExportExcelSheetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordPadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSPaintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileEntryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusHolderToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileEntryToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusHolderToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PayrollToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdvanceEntry1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentAdvanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsAttendance2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsPayment1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsPayment2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LibraryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksIssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksReservationToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SerialControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JournalsAndMagazinesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewspaperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusFeePaymentStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusFeePaymentStaffsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassFeePaymentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelFeePaymentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarksEntryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PayrollToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PayrollAdvanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffPaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalarySlipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksReservationToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BooksReturnToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchasedBooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BusFeeReceiptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffsToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseFeeReceiptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HostelFeeReceiptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoucherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DueListStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PartialDueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullDueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DueListStaffsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PartialDueToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullDueToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterEntryToolStripMenuItem, Me.StudentToolStripMenuItem1, Me.StaffsToolStripMenuItem7, Me.ExamToolStripMenuItem, Me.PayrollToolStripMenuItem, Me.LibraryToolStripMenuItem, Me.TransactionsToolStripMenuItem2, Me.AccountingToolStripMenuItem, Me.UtilitiesToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.RecordsToolStripMenuItem, Me.ReportToolStripMenuItem, Me.DatabaseToolStripMenuItem1, Me.AboutToolStripMenuItem, Me.LogoutToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1028, 73)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MasterEntryToolStripMenuItem
        '
        Me.MasterEntryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolTypeToolStripMenuItem, Me.SchoolInfoToolStripMenuItem, Me.HostelInfoToolStripMenuItem, Me.HouseInfoToolStripMenuItem, Me.BusInfoToolStripMenuItem, Me.SessionToolStripMenuItem, Me.LocationToolStripMenuItem, Me.FeeToolStripMenuItem, Me.FeeInfoToolStripMenuItem, Me.InstallmentToolStripMenuItem, Me.DiscountToolStripMenuItem})
        Me.MasterEntryToolStripMenuItem.Image = CType(resources.GetObject("MasterEntryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MasterEntryToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.MasterEntryToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.MasterEntryToolStripMenuItem.Name = "MasterEntryToolStripMenuItem"
        Me.MasterEntryToolStripMenuItem.Size = New System.Drawing.Size(99, 69)
        Me.MasterEntryToolStripMenuItem.Text = "Master Module"
        Me.MasterEntryToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SchoolTypeToolStripMenuItem
        '
        Me.SchoolTypeToolStripMenuItem.Name = "SchoolTypeToolStripMenuItem"
        Me.SchoolTypeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SchoolTypeToolStripMenuItem.Text = "School Type "
        '
        'SchoolInfoToolStripMenuItem
        '
        Me.SchoolInfoToolStripMenuItem.Name = "SchoolInfoToolStripMenuItem"
        Me.SchoolInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SchoolInfoToolStripMenuItem.Text = "School Info"
        '
        'HostelInfoToolStripMenuItem
        '
        Me.HostelInfoToolStripMenuItem.Name = "HostelInfoToolStripMenuItem"
        Me.HostelInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HostelInfoToolStripMenuItem.Text = "Hostel Info"
        '
        'HouseInfoToolStripMenuItem
        '
        Me.HouseInfoToolStripMenuItem.Name = "HouseInfoToolStripMenuItem"
        Me.HouseInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HouseInfoToolStripMenuItem.Text = "House Info"
        '
        'BusInfoToolStripMenuItem
        '
        Me.BusInfoToolStripMenuItem.Name = "BusInfoToolStripMenuItem"
        Me.BusInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BusInfoToolStripMenuItem.Text = "Bus Info"
        '
        'SessionToolStripMenuItem
        '
        Me.SessionToolStripMenuItem.Name = "SessionToolStripMenuItem"
        Me.SessionToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SessionToolStripMenuItem.Text = "Session"
        '
        'LocationToolStripMenuItem
        '
        Me.LocationToolStripMenuItem.Name = "LocationToolStripMenuItem"
        Me.LocationToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LocationToolStripMenuItem.Text = "Location"
        '
        'FeeToolStripMenuItem
        '
        Me.FeeToolStripMenuItem.Name = "FeeToolStripMenuItem"
        Me.FeeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FeeToolStripMenuItem.Text = "Fee"
        '
        'FeeInfoToolStripMenuItem
        '
        Me.FeeInfoToolStripMenuItem.Name = "FeeInfoToolStripMenuItem"
        Me.FeeInfoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FeeInfoToolStripMenuItem.Text = "Class Fee Entry"
        '
        'InstallmentToolStripMenuItem
        '
        Me.InstallmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BusFeeToolStripMenuItem, Me.HostelFeeToolStripMenuItem})
        Me.InstallmentToolStripMenuItem.Name = "InstallmentToolStripMenuItem"
        Me.InstallmentToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.InstallmentToolStripMenuItem.Text = "Installment"
        '
        'BusFeeToolStripMenuItem
        '
        Me.BusFeeToolStripMenuItem.Name = "BusFeeToolStripMenuItem"
        Me.BusFeeToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.BusFeeToolStripMenuItem.Text = "Bus Fee"
        '
        'HostelFeeToolStripMenuItem
        '
        Me.HostelFeeToolStripMenuItem.Name = "HostelFeeToolStripMenuItem"
        Me.HostelFeeToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.HostelFeeToolStripMenuItem.Text = "Hostel Fee"
        '
        'DiscountToolStripMenuItem
        '
        Me.DiscountToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem1, Me.StaffsToolStripMenuItem1})
        Me.DiscountToolStripMenuItem.Name = "DiscountToolStripMenuItem"
        Me.DiscountToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DiscountToolStripMenuItem.Text = "Discount"
        '
        'StudentsToolStripMenuItem1
        '
        Me.StudentsToolStripMenuItem1.Name = "StudentsToolStripMenuItem1"
        Me.StudentsToolStripMenuItem1.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem1.Text = "Students"
        '
        'StaffsToolStripMenuItem1
        '
        Me.StaffsToolStripMenuItem1.Name = "StaffsToolStripMenuItem1"
        Me.StaffsToolStripMenuItem1.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem1.Text = "Staffs"
        '
        'StudentToolStripMenuItem1
        '
        Me.StudentToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourseMasterToolStripMenuItem, Me.BranchMasterToolStripMenuItem, Me.SemesterMasterToolStripMenuItem, Me.DocumentMasterToolStripMenuItem, Me.AttendanceMasterToolStripMenuItem, Me.StudentMasterToolStripMenuItem, Me.AtteandanceToolStripMenuItem, Me.HostelerMasterToolStripMenuItem, Me.BusHoldersToolStripMenuItem, Me.PromotionToolStripMenuItem, Me.InactiveEntryToolStripMenuItem1, Me.IdentityCardToolStripMenuItem})
        Me.StudentToolStripMenuItem1.Image = CType(resources.GetObject("StudentToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.StudentToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StudentToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.StudentToolStripMenuItem1.Name = "StudentToolStripMenuItem1"
        Me.StudentToolStripMenuItem1.Size = New System.Drawing.Size(65, 69)
        Me.StudentToolStripMenuItem1.Text = "Students"
        Me.StudentToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CourseMasterToolStripMenuItem
        '
        Me.CourseMasterToolStripMenuItem.Name = "CourseMasterToolStripMenuItem"
        Me.CourseMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.CourseMasterToolStripMenuItem.Text = "Class Type Master"
        '
        'BranchMasterToolStripMenuItem
        '
        Me.BranchMasterToolStripMenuItem.Name = "BranchMasterToolStripMenuItem"
        Me.BranchMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.BranchMasterToolStripMenuItem.Text = "Class Master"
        '
        'SemesterMasterToolStripMenuItem
        '
        Me.SemesterMasterToolStripMenuItem.Name = "SemesterMasterToolStripMenuItem"
        Me.SemesterMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SemesterMasterToolStripMenuItem.Text = "Section/Stream Master"
        '
        'DocumentMasterToolStripMenuItem
        '
        Me.DocumentMasterToolStripMenuItem.Name = "DocumentMasterToolStripMenuItem"
        Me.DocumentMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.DocumentMasterToolStripMenuItem.Text = "Document Master"
        '
        'AttendanceMasterToolStripMenuItem
        '
        Me.AttendanceMasterToolStripMenuItem.Name = "AttendanceMasterToolStripMenuItem"
        Me.AttendanceMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.AttendanceMasterToolStripMenuItem.Text = "Attendance Type"
        '
        'StudentMasterToolStripMenuItem
        '
        Me.StudentMasterToolStripMenuItem.Name = "StudentMasterToolStripMenuItem"
        Me.StudentMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.StudentMasterToolStripMenuItem.Text = "Student Entry"
        '
        'AtteandanceToolStripMenuItem
        '
        Me.AtteandanceToolStripMenuItem.Name = "AtteandanceToolStripMenuItem"
        Me.AtteandanceToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.AtteandanceToolStripMenuItem.Text = "Attendance"
        '
        'HostelerMasterToolStripMenuItem
        '
        Me.HostelerMasterToolStripMenuItem.Name = "HostelerMasterToolStripMenuItem"
        Me.HostelerMasterToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.HostelerMasterToolStripMenuItem.Text = "Hostelers Entry"
        '
        'BusHoldersToolStripMenuItem
        '
        Me.BusHoldersToolStripMenuItem.Name = "BusHoldersToolStripMenuItem"
        Me.BusHoldersToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.BusHoldersToolStripMenuItem.Text = "Bus Holders"
        '
        'PromotionToolStripMenuItem
        '
        Me.PromotionToolStripMenuItem.Name = "PromotionToolStripMenuItem"
        Me.PromotionToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.PromotionToolStripMenuItem.Text = "Class Promotion"
        '
        'InactiveEntryToolStripMenuItem1
        '
        Me.InactiveEntryToolStripMenuItem1.Name = "InactiveEntryToolStripMenuItem1"
        Me.InactiveEntryToolStripMenuItem1.Size = New System.Drawing.Size(194, 22)
        Me.InactiveEntryToolStripMenuItem1.Text = "Inactive Entry"
        '
        'IdentityCardToolStripMenuItem
        '
        Me.IdentityCardToolStripMenuItem.Name = "IdentityCardToolStripMenuItem"
        Me.IdentityCardToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.IdentityCardToolStripMenuItem.Text = "Identity Card"
        '
        'StaffsToolStripMenuItem7
        '
        Me.StaffsToolStripMenuItem7.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentMasterToolStripMenuItem1, Me.DesignationMasterToolStripMenuItem1, Me.ProfileEntryToolStripMenuItem, Me.BusHoldersToolStripMenuItem1})
        Me.StaffsToolStripMenuItem7.Image = CType(resources.GetObject("StaffsToolStripMenuItem7.Image"), System.Drawing.Image)
        Me.StaffsToolStripMenuItem7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StaffsToolStripMenuItem7.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.StaffsToolStripMenuItem7.Name = "StaffsToolStripMenuItem7"
        Me.StaffsToolStripMenuItem7.Size = New System.Drawing.Size(62, 69)
        Me.StaffsToolStripMenuItem7.Text = "Staff "
        Me.StaffsToolStripMenuItem7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DepartmentMasterToolStripMenuItem1
        '
        Me.DepartmentMasterToolStripMenuItem1.Name = "DepartmentMasterToolStripMenuItem1"
        Me.DepartmentMasterToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.DepartmentMasterToolStripMenuItem1.Text = "Department Master"
        '
        'DesignationMasterToolStripMenuItem1
        '
        Me.DesignationMasterToolStripMenuItem1.Name = "DesignationMasterToolStripMenuItem1"
        Me.DesignationMasterToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.DesignationMasterToolStripMenuItem1.Text = "Designation Master"
        '
        'ProfileEntryToolStripMenuItem
        '
        Me.ProfileEntryToolStripMenuItem.Name = "ProfileEntryToolStripMenuItem"
        Me.ProfileEntryToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.ProfileEntryToolStripMenuItem.Text = "Profile Entry"
        '
        'BusHoldersToolStripMenuItem1
        '
        Me.BusHoldersToolStripMenuItem1.Name = "BusHoldersToolStripMenuItem1"
        Me.BusHoldersToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.BusHoldersToolStripMenuItem1.Text = "Bus Holders"
        '
        'ExamToolStripMenuItem
        '
        Me.ExamToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SubjectMasterToolStripMenuItem, Me.ExamTypeToolStripMenuItem, Me.ExamEntryToolStripMenuItem, Me.GradeMasterToolStripMenuItem, Me.MarksEntryToolStripMenuItem, Me.MarksheetLedgerToolStripMenuItem})
        Me.ExamToolStripMenuItem.Image = CType(resources.GetObject("ExamToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExamToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ExamToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.ExamToolStripMenuItem.Name = "ExamToolStripMenuItem"
        Me.ExamToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.ExamToolStripMenuItem.Text = "Exam"
        Me.ExamToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SubjectMasterToolStripMenuItem
        '
        Me.SubjectMasterToolStripMenuItem.Name = "SubjectMasterToolStripMenuItem"
        Me.SubjectMasterToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.SubjectMasterToolStripMenuItem.Text = "Subject Master"
        '
        'ExamTypeToolStripMenuItem
        '
        Me.ExamTypeToolStripMenuItem.Name = "ExamTypeToolStripMenuItem"
        Me.ExamTypeToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ExamTypeToolStripMenuItem.Text = "Exam Type"
        '
        'ExamEntryToolStripMenuItem
        '
        Me.ExamEntryToolStripMenuItem.Name = "ExamEntryToolStripMenuItem"
        Me.ExamEntryToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ExamEntryToolStripMenuItem.Text = "Exam Entry"
        '
        'GradeMasterToolStripMenuItem
        '
        Me.GradeMasterToolStripMenuItem.Name = "GradeMasterToolStripMenuItem"
        Me.GradeMasterToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.GradeMasterToolStripMenuItem.Text = "Grade Master"
        '
        'MarksEntryToolStripMenuItem
        '
        Me.MarksEntryToolStripMenuItem.Name = "MarksEntryToolStripMenuItem"
        Me.MarksEntryToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.MarksEntryToolStripMenuItem.Text = "Marks Entry"
        '
        'MarksheetLedgerToolStripMenuItem
        '
        Me.MarksheetLedgerToolStripMenuItem.Name = "MarksheetLedgerToolStripMenuItem"
        Me.MarksheetLedgerToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.MarksheetLedgerToolStripMenuItem.Text = "Marksheet Ledger"
        '
        'PayrollToolStripMenuItem
        '
        Me.PayrollToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentMasterToolStripMenuItem, Me.DesignationMasterToolStripMenuItem, Me.StaffMasterToolStripMenuItem, Me.AdvanceEntryToolStripMenuItem, Me.AtteanceEntryToolStripMenuItem, Me.PaymentToolStripMenuItem})
        Me.PayrollToolStripMenuItem.Image = CType(resources.GetObject("PayrollToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PayrollToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PayrollToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.PayrollToolStripMenuItem.Name = "PayrollToolStripMenuItem"
        Me.PayrollToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.PayrollToolStripMenuItem.Text = "Payroll"
        Me.PayrollToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DepartmentMasterToolStripMenuItem
        '
        Me.DepartmentMasterToolStripMenuItem.Name = "DepartmentMasterToolStripMenuItem"
        Me.DepartmentMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.DepartmentMasterToolStripMenuItem.Text = "Department Master"
        '
        'DesignationMasterToolStripMenuItem
        '
        Me.DesignationMasterToolStripMenuItem.Name = "DesignationMasterToolStripMenuItem"
        Me.DesignationMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.DesignationMasterToolStripMenuItem.Text = "Designation Master"
        '
        'StaffMasterToolStripMenuItem
        '
        Me.StaffMasterToolStripMenuItem.Name = "StaffMasterToolStripMenuItem"
        Me.StaffMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.StaffMasterToolStripMenuItem.Text = "Staffs Entry"
        '
        'AdvanceEntryToolStripMenuItem
        '
        Me.AdvanceEntryToolStripMenuItem.Name = "AdvanceEntryToolStripMenuItem"
        Me.AdvanceEntryToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.AdvanceEntryToolStripMenuItem.Text = "Payroll Advance"
        '
        'AtteanceEntryToolStripMenuItem
        '
        Me.AtteanceEntryToolStripMenuItem.Name = "AtteanceEntryToolStripMenuItem"
        Me.AtteanceEntryToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.AtteanceEntryToolStripMenuItem.Text = "Attendance Entry"
        '
        'PaymentToolStripMenuItem
        '
        Me.PaymentToolStripMenuItem.Name = "PaymentToolStripMenuItem"
        Me.PaymentToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.PaymentToolStripMenuItem.Text = "Payment"
        '
        'LibraryToolStripMenuItem
        '
        Me.LibraryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingToolStripMenuItem, Me.SupplierMasterToolStripMenuItem, Me.BooksClassificationToolStripMenuItem, Me.BookMasterToolStripMenuItem, Me.NewspaperMasterToolStripMenuItem, Me.JournalsAndMagazinesToolStripMenuItem, Me.NewspaperEntryToolStripMenuItem, Me.BookIssueToolStripMenuItem, Me.BookReturnToolStripMenuItem, Me.BooksReservationToolStripMenuItem, Me.QuotationToolStripMenuItem})
        Me.LibraryToolStripMenuItem.Image = CType(resources.GetObject("LibraryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LibraryToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LibraryToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.LibraryToolStripMenuItem.Name = "LibraryToolStripMenuItem"
        Me.LibraryToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.LibraryToolStripMenuItem.Text = "Library"
        Me.LibraryToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SettingToolStripMenuItem
        '
        Me.SettingToolStripMenuItem.Name = "SettingToolStripMenuItem"
        Me.SettingToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.SettingToolStripMenuItem.Text = "Setting"
        '
        'SupplierMasterToolStripMenuItem
        '
        Me.SupplierMasterToolStripMenuItem.Name = "SupplierMasterToolStripMenuItem"
        Me.SupplierMasterToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.SupplierMasterToolStripMenuItem.Text = "Supplier Master"
        '
        'BooksClassificationToolStripMenuItem
        '
        Me.BooksClassificationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClassToolStripMenuItem, Me.CategoryToolStripMenuItem, Me.SubCategoryToolStripMenuItem})
        Me.BooksClassificationToolStripMenuItem.Name = "BooksClassificationToolStripMenuItem"
        Me.BooksClassificationToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.BooksClassificationToolStripMenuItem.Text = "Books Classification"
        '
        'ClassToolStripMenuItem
        '
        Me.ClassToolStripMenuItem.Name = "ClassToolStripMenuItem"
        Me.ClassToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ClassToolStripMenuItem.Text = "Class"
        '
        'CategoryToolStripMenuItem
        '
        Me.CategoryToolStripMenuItem.Name = "CategoryToolStripMenuItem"
        Me.CategoryToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.CategoryToolStripMenuItem.Text = "Category"
        '
        'SubCategoryToolStripMenuItem
        '
        Me.SubCategoryToolStripMenuItem.Name = "SubCategoryToolStripMenuItem"
        Me.SubCategoryToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.SubCategoryToolStripMenuItem.Text = "Sub Category"
        '
        'BookMasterToolStripMenuItem
        '
        Me.BookMasterToolStripMenuItem.Name = "BookMasterToolStripMenuItem"
        Me.BookMasterToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.BookMasterToolStripMenuItem.Text = "Book Master"
        '
        'NewspaperMasterToolStripMenuItem
        '
        Me.NewspaperMasterToolStripMenuItem.Name = "NewspaperMasterToolStripMenuItem"
        Me.NewspaperMasterToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.NewspaperMasterToolStripMenuItem.Text = "Newspaper Master"
        '
        'JournalsAndMagazinesToolStripMenuItem
        '
        Me.JournalsAndMagazinesToolStripMenuItem.Name = "JournalsAndMagazinesToolStripMenuItem"
        Me.JournalsAndMagazinesToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.JournalsAndMagazinesToolStripMenuItem.Text = "Journals and Magazines"
        '
        'NewspaperEntryToolStripMenuItem
        '
        Me.NewspaperEntryToolStripMenuItem.Name = "NewspaperEntryToolStripMenuItem"
        Me.NewspaperEntryToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.NewspaperEntryToolStripMenuItem.Text = "Newspaper Entry"
        '
        'BookIssueToolStripMenuItem
        '
        Me.BookIssueToolStripMenuItem.Name = "BookIssueToolStripMenuItem"
        Me.BookIssueToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.BookIssueToolStripMenuItem.Text = "Book Issue"
        '
        'BookReturnToolStripMenuItem
        '
        Me.BookReturnToolStripMenuItem.Name = "BookReturnToolStripMenuItem"
        Me.BookReturnToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.BookReturnToolStripMenuItem.Text = "Book Return"
        '
        'BooksReservationToolStripMenuItem
        '
        Me.BooksReservationToolStripMenuItem.Name = "BooksReservationToolStripMenuItem"
        Me.BooksReservationToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.BooksReservationToolStripMenuItem.Text = "Book Reservation"
        '
        'QuotationToolStripMenuItem
        '
        Me.QuotationToolStripMenuItem.Name = "QuotationToolStripMenuItem"
        Me.QuotationToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.QuotationToolStripMenuItem.Text = "Quotation"
        '
        'TransactionsToolStripMenuItem2
        '
        Me.TransactionsToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BusFeePaymentToolStripMenuItem, Me.ClassFeePaymentToolStripMenuItem, Me.HostelFeePaymentToolStripMenuItem})
        Me.TransactionsToolStripMenuItem2.Image = CType(resources.GetObject("TransactionsToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.TransactionsToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TransactionsToolStripMenuItem2.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.TransactionsToolStripMenuItem2.Name = "TransactionsToolStripMenuItem2"
        Me.TransactionsToolStripMenuItem2.Size = New System.Drawing.Size(86, 69)
        Me.TransactionsToolStripMenuItem2.Text = "Transactions"
        Me.TransactionsToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'BusFeePaymentToolStripMenuItem
        '
        Me.BusFeePaymentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem8, Me.StaffsToolStripMenuItem8})
        Me.BusFeePaymentToolStripMenuItem.Name = "BusFeePaymentToolStripMenuItem"
        Me.BusFeePaymentToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.BusFeePaymentToolStripMenuItem.Text = "Bus Fee Payment"
        '
        'StudentsToolStripMenuItem8
        '
        Me.StudentsToolStripMenuItem8.Name = "StudentsToolStripMenuItem8"
        Me.StudentsToolStripMenuItem8.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem8.Text = "Students"
        '
        'StaffsToolStripMenuItem8
        '
        Me.StaffsToolStripMenuItem8.Name = "StaffsToolStripMenuItem8"
        Me.StaffsToolStripMenuItem8.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem8.Text = "Staffs"
        '
        'ClassFeePaymentToolStripMenuItem
        '
        Me.ClassFeePaymentToolStripMenuItem.Name = "ClassFeePaymentToolStripMenuItem"
        Me.ClassFeePaymentToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.ClassFeePaymentToolStripMenuItem.Text = "Class Fee Payment"
        '
        'HostelFeePaymentToolStripMenuItem
        '
        Me.HostelFeePaymentToolStripMenuItem.Name = "HostelFeePaymentToolStripMenuItem"
        Me.HostelFeePaymentToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.HostelFeePaymentToolStripMenuItem.Text = "Hostel Fee Payment"
        '
        'AccountingToolStripMenuItem
        '
        Me.AccountingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExpenseMasterToolStripMenuItem, Me.ExpensesToolStripMenuItem1, Me.VoucherToolStripMenuItem1, Me.PurchaseDaybookToolStripMenuItem, Me.DaybookToolStripMenuItem, Me.GeneralLedgerToolStripMenuItem, Me.SupplierLedgerToolStripMenuItem, Me.TrialBalanceToolStripMenuItem})
        Me.AccountingToolStripMenuItem.Image = CType(resources.GetObject("AccountingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AccountingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AccountingToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.AccountingToolStripMenuItem.Name = "AccountingToolStripMenuItem"
        Me.AccountingToolStripMenuItem.Size = New System.Drawing.Size(81, 69)
        Me.AccountingToolStripMenuItem.Text = "Accounting"
        Me.AccountingToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ExpenseMasterToolStripMenuItem
        '
        Me.ExpenseMasterToolStripMenuItem.Name = "ExpenseMasterToolStripMenuItem"
        Me.ExpenseMasterToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ExpenseMasterToolStripMenuItem.Text = "Expense Type  Master"
        '
        'ExpensesToolStripMenuItem1
        '
        Me.ExpensesToolStripMenuItem1.Name = "ExpensesToolStripMenuItem1"
        Me.ExpensesToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.ExpensesToolStripMenuItem1.Text = "Expense Master"
        '
        'VoucherToolStripMenuItem1
        '
        Me.VoucherToolStripMenuItem1.Name = "VoucherToolStripMenuItem1"
        Me.VoucherToolStripMenuItem1.Size = New System.Drawing.Size(187, 22)
        Me.VoucherToolStripMenuItem1.Text = "Voucher"
        '
        'PurchaseDaybookToolStripMenuItem
        '
        Me.PurchaseDaybookToolStripMenuItem.Name = "PurchaseDaybookToolStripMenuItem"
        Me.PurchaseDaybookToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PurchaseDaybookToolStripMenuItem.Text = "Purchase Daybook"
        '
        'DaybookToolStripMenuItem
        '
        Me.DaybookToolStripMenuItem.Name = "DaybookToolStripMenuItem"
        Me.DaybookToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.DaybookToolStripMenuItem.Text = "General Daybook"
        '
        'GeneralLedgerToolStripMenuItem
        '
        Me.GeneralLedgerToolStripMenuItem.Name = "GeneralLedgerToolStripMenuItem"
        Me.GeneralLedgerToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.GeneralLedgerToolStripMenuItem.Text = "General Ledger"
        '
        'SupplierLedgerToolStripMenuItem
        '
        Me.SupplierLedgerToolStripMenuItem.Name = "SupplierLedgerToolStripMenuItem"
        Me.SupplierLedgerToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.SupplierLedgerToolStripMenuItem.Text = "Supplier Ledger"
        '
        'TrialBalanceToolStripMenuItem
        '
        Me.TrialBalanceToolStripMenuItem.Name = "TrialBalanceToolStripMenuItem"
        Me.TrialBalanceToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.TrialBalanceToolStripMenuItem.Text = "Trial Balance"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UsersRegistrationToolStripMenuItem, Me.ChangePasswordToolStripMenuItem, Me.SMSSettingToolStripMenuItem, Me.EmailSettingToolStripMenuItem, Me.SQLServerSettingToolStripMenuItem, Me.LogsToolStripMenuItem, Me.ImportExportExcelSheetToolStripMenuItem})
        Me.UtilitiesToolStripMenuItem.Image = CType(resources.GetObject("UtilitiesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UtilitiesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UtilitiesToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        Me.UtilitiesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'UsersRegistrationToolStripMenuItem
        '
        Me.UsersRegistrationToolStripMenuItem.Name = "UsersRegistrationToolStripMenuItem"
        Me.UsersRegistrationToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.UsersRegistrationToolStripMenuItem.Text = "Users Registration"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'SMSSettingToolStripMenuItem
        '
        Me.SMSSettingToolStripMenuItem.Name = "SMSSettingToolStripMenuItem"
        Me.SMSSettingToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.SMSSettingToolStripMenuItem.Text = "SMS Setting"
        '
        'EmailSettingToolStripMenuItem
        '
        Me.EmailSettingToolStripMenuItem.Name = "EmailSettingToolStripMenuItem"
        Me.EmailSettingToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.EmailSettingToolStripMenuItem.Text = "Email Setting"
        '
        'SQLServerSettingToolStripMenuItem
        '
        Me.SQLServerSettingToolStripMenuItem.Name = "SQLServerSettingToolStripMenuItem"
        Me.SQLServerSettingToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.SQLServerSettingToolStripMenuItem.Text = "SQL Server Setting"
        '
        'LogsToolStripMenuItem
        '
        Me.LogsToolStripMenuItem.Name = "LogsToolStripMenuItem"
        Me.LogsToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.LogsToolStripMenuItem.Text = "Logs"
        '
        'ImportExportExcelSheetToolStripMenuItem
        '
        Me.ImportExportExcelSheetToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsRecordToolStripMenuItem, Me.StaffsRecordToolStripMenuItem, Me.BooksRecordToolStripMenuItem})
        Me.ImportExportExcelSheetToolStripMenuItem.Name = "ImportExportExcelSheetToolStripMenuItem"
        Me.ImportExportExcelSheetToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.ImportExportExcelSheetToolStripMenuItem.Text = "Import/Export Excel Sheet"
        '
        'StudentsRecordToolStripMenuItem
        '
        Me.StudentsRecordToolStripMenuItem.Name = "StudentsRecordToolStripMenuItem"
        Me.StudentsRecordToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.StudentsRecordToolStripMenuItem.Text = "Students Record"
        '
        'StaffsRecordToolStripMenuItem
        '
        Me.StaffsRecordToolStripMenuItem.Name = "StaffsRecordToolStripMenuItem"
        Me.StaffsRecordToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.StaffsRecordToolStripMenuItem.Text = "Staffs Record"
        '
        'BooksRecordToolStripMenuItem
        '
        Me.BooksRecordToolStripMenuItem.Name = "BooksRecordToolStripMenuItem"
        Me.BooksRecordToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.BooksRecordToolStripMenuItem.Text = "Books Record"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.WordPadToolStripMenuItem, Me.MSWordToolStripMenuItem, Me.MSPaintToolStripMenuItem, Me.TaskManagerToolStripMenuItem, Me.SystemInfoToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Image = CType(resources.GetObject("ToolsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ToolsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolsToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        Me.ToolsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'WordPadToolStripMenuItem
        '
        Me.WordPadToolStripMenuItem.Name = "WordPadToolStripMenuItem"
        Me.WordPadToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.WordPadToolStripMenuItem.Text = "Word Pad"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'MSPaintToolStripMenuItem
        '
        Me.MSPaintToolStripMenuItem.Name = "MSPaintToolStripMenuItem"
        Me.MSPaintToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.MSPaintToolStripMenuItem.Text = "MS Paint"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.TaskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'SystemInfoToolStripMenuItem
        '
        Me.SystemInfoToolStripMenuItem.Name = "SystemInfoToolStripMenuItem"
        Me.SystemInfoToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.SystemInfoToolStripMenuItem.Text = "System Info"
        '
        'RecordsToolStripMenuItem
        '
        Me.RecordsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem, Me.StaffsToolStripMenuItem, Me.PayrollToolStripMenuItem1, Me.LibraryToolStripMenuItem1, Me.TransactionsToolStripMenuItem, Me.InventoryToolStripMenuItem1, Me.MarksEntryToolStripMenuItem1})
        Me.RecordsToolStripMenuItem.Image = CType(resources.GetObject("RecordsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RecordsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RecordsToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.RecordsToolStripMenuItem.Name = "RecordsToolStripMenuItem"
        Me.RecordsToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.RecordsToolStripMenuItem.Text = "Search"
        Me.RecordsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StudentsToolStripMenuItem
        '
        Me.StudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileEntryToolStripMenuItem1, Me.HostelerToolStripMenuItem1, Me.BusHolderToolStripMenuItem2, Me.AttendanceToolStripMenuItem})
        Me.StudentsToolStripMenuItem.Name = "StudentsToolStripMenuItem"
        Me.StudentsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.StudentsToolStripMenuItem.Text = "Students"
        '
        'ProfileEntryToolStripMenuItem1
        '
        Me.ProfileEntryToolStripMenuItem1.Name = "ProfileEntryToolStripMenuItem1"
        Me.ProfileEntryToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.ProfileEntryToolStripMenuItem1.Text = "Profile Entry"
        '
        'HostelerToolStripMenuItem1
        '
        Me.HostelerToolStripMenuItem1.Name = "HostelerToolStripMenuItem1"
        Me.HostelerToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.HostelerToolStripMenuItem1.Text = "Hosteler"
        '
        'BusHolderToolStripMenuItem2
        '
        Me.BusHolderToolStripMenuItem2.Name = "BusHolderToolStripMenuItem2"
        Me.BusHolderToolStripMenuItem2.Size = New System.Drawing.Size(138, 22)
        Me.BusHolderToolStripMenuItem2.Text = "Bus Holder"
        '
        'AttendanceToolStripMenuItem
        '
        Me.AttendanceToolStripMenuItem.Name = "AttendanceToolStripMenuItem"
        Me.AttendanceToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.AttendanceToolStripMenuItem.Text = "Attendance"
        '
        'StaffsToolStripMenuItem
        '
        Me.StaffsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileEntryToolStripMenuItem3, Me.BusHolderToolStripMenuItem3})
        Me.StaffsToolStripMenuItem.Name = "StaffsToolStripMenuItem"
        Me.StaffsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.StaffsToolStripMenuItem.Text = "Staffs"
        '
        'ProfileEntryToolStripMenuItem3
        '
        Me.ProfileEntryToolStripMenuItem3.Name = "ProfileEntryToolStripMenuItem3"
        Me.ProfileEntryToolStripMenuItem3.Size = New System.Drawing.Size(138, 22)
        Me.ProfileEntryToolStripMenuItem3.Text = "Profile Entry"
        '
        'BusHolderToolStripMenuItem3
        '
        Me.BusHolderToolStripMenuItem3.Name = "BusHolderToolStripMenuItem3"
        Me.BusHolderToolStripMenuItem3.Size = New System.Drawing.Size(138, 22)
        Me.BusHolderToolStripMenuItem3.Text = "Bus Holder"
        '
        'PayrollToolStripMenuItem1
        '
        Me.PayrollToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdvanceEntry1ToolStripMenuItem, Me.CurrentAdvanceToolStripMenuItem, Me.StaffsAttendanceToolStripMenuItem, Me.StaffsAttendance2ToolStripMenuItem, Me.StaffsPayment1ToolStripMenuItem, Me.StaffsPayment2ToolStripMenuItem})
        Me.PayrollToolStripMenuItem1.Name = "PayrollToolStripMenuItem1"
        Me.PayrollToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.PayrollToolStripMenuItem1.Text = "Payroll"
        '
        'AdvanceEntry1ToolStripMenuItem
        '
        Me.AdvanceEntry1ToolStripMenuItem.Name = "AdvanceEntry1ToolStripMenuItem"
        Me.AdvanceEntry1ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.AdvanceEntry1ToolStripMenuItem.Text = "Payroll Adavnce"
        '
        'CurrentAdvanceToolStripMenuItem
        '
        Me.CurrentAdvanceToolStripMenuItem.Name = "CurrentAdvanceToolStripMenuItem"
        Me.CurrentAdvanceToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CurrentAdvanceToolStripMenuItem.Text = "Current Advance"
        '
        'StaffsAttendanceToolStripMenuItem
        '
        Me.StaffsAttendanceToolStripMenuItem.Name = "StaffsAttendanceToolStripMenuItem"
        Me.StaffsAttendanceToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.StaffsAttendanceToolStripMenuItem.Text = "Staffs Attendance 1"
        '
        'StaffsAttendance2ToolStripMenuItem
        '
        Me.StaffsAttendance2ToolStripMenuItem.Name = "StaffsAttendance2ToolStripMenuItem"
        Me.StaffsAttendance2ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.StaffsAttendance2ToolStripMenuItem.Text = "Staffs Attendance 2"
        '
        'StaffsPayment1ToolStripMenuItem
        '
        Me.StaffsPayment1ToolStripMenuItem.Name = "StaffsPayment1ToolStripMenuItem"
        Me.StaffsPayment1ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.StaffsPayment1ToolStripMenuItem.Text = "Staffs Payment 1"
        '
        'StaffsPayment2ToolStripMenuItem
        '
        Me.StaffsPayment2ToolStripMenuItem.Name = "StaffsPayment2ToolStripMenuItem"
        Me.StaffsPayment2ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.StaffsPayment2ToolStripMenuItem.Text = "Staffs Payment 2"
        '
        'LibraryToolStripMenuItem1
        '
        Me.LibraryToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BooksToolStripMenuItem, Me.BooksIssueToolStripMenuItem, Me.BooksReservationToolStripMenuItem1, Me.BooksReturnToolStripMenuItem, Me.SerialControlToolStripMenuItem, Me.SuppliersToolStripMenuItem})
        Me.LibraryToolStripMenuItem1.Name = "LibraryToolStripMenuItem1"
        Me.LibraryToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.LibraryToolStripMenuItem1.Text = "Library"
        '
        'BooksToolStripMenuItem
        '
        Me.BooksToolStripMenuItem.Name = "BooksToolStripMenuItem"
        Me.BooksToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.BooksToolStripMenuItem.Text = "Books Entry"
        '
        'BooksIssueToolStripMenuItem
        '
        Me.BooksIssueToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem2, Me.StaffsToolStripMenuItem2})
        Me.BooksIssueToolStripMenuItem.Name = "BooksIssueToolStripMenuItem"
        Me.BooksIssueToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.BooksIssueToolStripMenuItem.Text = "Books Issue"
        '
        'StudentsToolStripMenuItem2
        '
        Me.StudentsToolStripMenuItem2.Name = "StudentsToolStripMenuItem2"
        Me.StudentsToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem2.Text = "Students"
        '
        'StaffsToolStripMenuItem2
        '
        Me.StaffsToolStripMenuItem2.Name = "StaffsToolStripMenuItem2"
        Me.StaffsToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem2.Text = "Staffs"
        '
        'BooksReservationToolStripMenuItem1
        '
        Me.BooksReservationToolStripMenuItem1.Name = "BooksReservationToolStripMenuItem1"
        Me.BooksReservationToolStripMenuItem1.Size = New System.Drawing.Size(170, 22)
        Me.BooksReservationToolStripMenuItem1.Text = "Books Reservation"
        '
        'BooksReturnToolStripMenuItem
        '
        Me.BooksReturnToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem3, Me.StaffsToolStripMenuItem3})
        Me.BooksReturnToolStripMenuItem.Name = "BooksReturnToolStripMenuItem"
        Me.BooksReturnToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.BooksReturnToolStripMenuItem.Text = "Books Return"
        '
        'StudentsToolStripMenuItem3
        '
        Me.StudentsToolStripMenuItem3.Name = "StudentsToolStripMenuItem3"
        Me.StudentsToolStripMenuItem3.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem3.Text = "Students"
        '
        'StaffsToolStripMenuItem3
        '
        Me.StaffsToolStripMenuItem3.Name = "StaffsToolStripMenuItem3"
        Me.StaffsToolStripMenuItem3.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem3.Text = "Staffs"
        '
        'SerialControlToolStripMenuItem
        '
        Me.SerialControlToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JournalsAndMagazinesToolStripMenuItem1, Me.NewspaperToolStripMenuItem})
        Me.SerialControlToolStripMenuItem.Name = "SerialControlToolStripMenuItem"
        Me.SerialControlToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.SerialControlToolStripMenuItem.Text = "Serial Control"
        '
        'JournalsAndMagazinesToolStripMenuItem1
        '
        Me.JournalsAndMagazinesToolStripMenuItem1.Name = "JournalsAndMagazinesToolStripMenuItem1"
        Me.JournalsAndMagazinesToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.JournalsAndMagazinesToolStripMenuItem1.Text = "Journals and Magazines"
        '
        'NewspaperToolStripMenuItem
        '
        Me.NewspaperToolStripMenuItem.Name = "NewspaperToolStripMenuItem"
        Me.NewspaperToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.NewspaperToolStripMenuItem.Text = "Newspaper"
        '
        'SuppliersToolStripMenuItem
        '
        Me.SuppliersToolStripMenuItem.Name = "SuppliersToolStripMenuItem"
        Me.SuppliersToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.SuppliersToolStripMenuItem.Text = "Suppliers"
        '
        'TransactionsToolStripMenuItem
        '
        Me.TransactionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BusFeePaymentStudentsToolStripMenuItem, Me.BusFeePaymentStaffsToolStripMenuItem, Me.ClassFeePaymentToolStripMenuItem1, Me.HostelFeePaymentToolStripMenuItem1})
        Me.TransactionsToolStripMenuItem.Name = "TransactionsToolStripMenuItem"
        Me.TransactionsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TransactionsToolStripMenuItem.Text = "Transactions"
        '
        'BusFeePaymentStudentsToolStripMenuItem
        '
        Me.BusFeePaymentStudentsToolStripMenuItem.Name = "BusFeePaymentStudentsToolStripMenuItem"
        Me.BusFeePaymentStudentsToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.BusFeePaymentStudentsToolStripMenuItem.Text = "Bus Fee Payment [Students]"
        '
        'BusFeePaymentStaffsToolStripMenuItem
        '
        Me.BusFeePaymentStaffsToolStripMenuItem.Name = "BusFeePaymentStaffsToolStripMenuItem"
        Me.BusFeePaymentStaffsToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.BusFeePaymentStaffsToolStripMenuItem.Text = "Bus Fee Payment [Staffs]"
        '
        'ClassFeePaymentToolStripMenuItem1
        '
        Me.ClassFeePaymentToolStripMenuItem1.Name = "ClassFeePaymentToolStripMenuItem1"
        Me.ClassFeePaymentToolStripMenuItem1.Size = New System.Drawing.Size(221, 22)
        Me.ClassFeePaymentToolStripMenuItem1.Text = "Class Fee Payment"
        '
        'HostelFeePaymentToolStripMenuItem1
        '
        Me.HostelFeePaymentToolStripMenuItem1.Name = "HostelFeePaymentToolStripMenuItem1"
        Me.HostelFeePaymentToolStripMenuItem1.Size = New System.Drawing.Size(221, 22)
        Me.HostelFeePaymentToolStripMenuItem1.Text = "Hostel Fee Payment"
        '
        'InventoryToolStripMenuItem1
        '
        Me.InventoryToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductsToolStripMenuItem, Me.SuppliersToolStripMenuItem1, Me.PurchaseToolStripMenuItem1, Me.PaymentToolStripMenuItem2})
        Me.InventoryToolStripMenuItem1.Name = "InventoryToolStripMenuItem1"
        Me.InventoryToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.InventoryToolStripMenuItem1.Text = "Inventory"
        '
        'ProductsToolStripMenuItem
        '
        Me.ProductsToolStripMenuItem.Name = "ProductsToolStripMenuItem"
        Me.ProductsToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.ProductsToolStripMenuItem.Text = "Products"
        '
        'SuppliersToolStripMenuItem1
        '
        Me.SuppliersToolStripMenuItem1.Name = "SuppliersToolStripMenuItem1"
        Me.SuppliersToolStripMenuItem1.Size = New System.Drawing.Size(122, 22)
        Me.SuppliersToolStripMenuItem1.Text = "Suppliers"
        '
        'PurchaseToolStripMenuItem1
        '
        Me.PurchaseToolStripMenuItem1.Name = "PurchaseToolStripMenuItem1"
        Me.PurchaseToolStripMenuItem1.Size = New System.Drawing.Size(122, 22)
        Me.PurchaseToolStripMenuItem1.Text = "Purchase"
        '
        'PaymentToolStripMenuItem2
        '
        Me.PaymentToolStripMenuItem2.Name = "PaymentToolStripMenuItem2"
        Me.PaymentToolStripMenuItem2.Size = New System.Drawing.Size(122, 22)
        Me.PaymentToolStripMenuItem2.Text = "Payment"
        '
        'MarksEntryToolStripMenuItem1
        '
        Me.MarksEntryToolStripMenuItem1.Name = "MarksEntryToolStripMenuItem1"
        Me.MarksEntryToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.MarksEntryToolStripMenuItem1.Text = "Marks Entry"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PayrollToolStripMenuItem2, Me.ToolStripMenuItem1, Me.TransactionsToolStripMenuItem1, Me.StudentsToolStripMenuItem7, Me.DueListStudentsToolStripMenuItem, Me.DueListStaffsToolStripMenuItem})
        Me.ReportToolStripMenuItem.Image = CType(resources.GetObject("ReportToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReportToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ReportToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.ReportToolStripMenuItem.Text = "Reports"
        Me.ReportToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'PayrollToolStripMenuItem2
        '
        Me.PayrollToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PayrollAdvanceToolStripMenuItem, Me.StaffPaymentToolStripMenuItem, Me.SalarySlipToolStripMenuItem})
        Me.PayrollToolStripMenuItem2.Name = "PayrollToolStripMenuItem2"
        Me.PayrollToolStripMenuItem2.Size = New System.Drawing.Size(199, 22)
        Me.PayrollToolStripMenuItem2.Text = "Payroll"
        '
        'PayrollAdvanceToolStripMenuItem
        '
        Me.PayrollAdvanceToolStripMenuItem.Name = "PayrollAdvanceToolStripMenuItem"
        Me.PayrollAdvanceToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.PayrollAdvanceToolStripMenuItem.Text = "Payroll Advance"
        '
        'StaffPaymentToolStripMenuItem
        '
        Me.StaffPaymentToolStripMenuItem.Name = "StaffPaymentToolStripMenuItem"
        Me.StaffPaymentToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.StaffPaymentToolStripMenuItem.Text = "Staff Payment"
        '
        'SalarySlipToolStripMenuItem
        '
        Me.SalarySlipToolStripMenuItem.Name = "SalarySlipToolStripMenuItem"
        Me.SalarySlipToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.SalarySlipToolStripMenuItem.Text = "Salary Slip"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.BooksReservationToolStripMenuItem2, Me.BooksReturnToolStripMenuItem1, Me.ToolStripMenuItem15, Me.PurchasedBooksToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.ToolStripMenuItem1.Text = "Library"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem4, Me.StaffsToolStripMenuItem4})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(170, 22)
        Me.ToolStripMenuItem2.Text = "Books Issue"
        '
        'StudentsToolStripMenuItem4
        '
        Me.StudentsToolStripMenuItem4.Name = "StudentsToolStripMenuItem4"
        Me.StudentsToolStripMenuItem4.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem4.Text = "Students"
        '
        'StaffsToolStripMenuItem4
        '
        Me.StaffsToolStripMenuItem4.Name = "StaffsToolStripMenuItem4"
        Me.StaffsToolStripMenuItem4.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem4.Text = "Staffs"
        '
        'BooksReservationToolStripMenuItem2
        '
        Me.BooksReservationToolStripMenuItem2.Name = "BooksReservationToolStripMenuItem2"
        Me.BooksReservationToolStripMenuItem2.Size = New System.Drawing.Size(170, 22)
        Me.BooksReservationToolStripMenuItem2.Text = "Books Reservation"
        '
        'BooksReturnToolStripMenuItem1
        '
        Me.BooksReturnToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem5, Me.StaffsToolStripMenuItem5})
        Me.BooksReturnToolStripMenuItem1.Name = "BooksReturnToolStripMenuItem1"
        Me.BooksReturnToolStripMenuItem1.Size = New System.Drawing.Size(170, 22)
        Me.BooksReturnToolStripMenuItem1.Text = "Books Return"
        '
        'StudentsToolStripMenuItem5
        '
        Me.StudentsToolStripMenuItem5.Name = "StudentsToolStripMenuItem5"
        Me.StudentsToolStripMenuItem5.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem5.Text = "Students"
        '
        'StaffsToolStripMenuItem5
        '
        Me.StaffsToolStripMenuItem5.Name = "StaffsToolStripMenuItem5"
        Me.StaffsToolStripMenuItem5.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem5.Text = "Staffs"
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem16, Me.ToolStripMenuItem17})
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(170, 22)
        Me.ToolStripMenuItem15.Text = "Fine Collection"
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(120, 22)
        Me.ToolStripMenuItem16.Text = "Students"
        '
        'ToolStripMenuItem17
        '
        Me.ToolStripMenuItem17.Name = "ToolStripMenuItem17"
        Me.ToolStripMenuItem17.Size = New System.Drawing.Size(120, 22)
        Me.ToolStripMenuItem17.Text = "Staffs"
        '
        'PurchasedBooksToolStripMenuItem
        '
        Me.PurchasedBooksToolStripMenuItem.Name = "PurchasedBooksToolStripMenuItem"
        Me.PurchasedBooksToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.PurchasedBooksToolStripMenuItem.Text = "Purchased Books"
        '
        'TransactionsToolStripMenuItem1
        '
        Me.TransactionsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BusFeeReceiptToolStripMenuItem, Me.CourseFeeReceiptToolStripMenuItem, Me.HostelFeeReceiptToolStripMenuItem, Me.VoucherToolStripMenuItem})
        Me.TransactionsToolStripMenuItem1.Name = "TransactionsToolStripMenuItem1"
        Me.TransactionsToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
        Me.TransactionsToolStripMenuItem1.Text = "Transactions"
        '
        'BusFeeReceiptToolStripMenuItem
        '
        Me.BusFeeReceiptToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem6, Me.StaffsToolStripMenuItem6})
        Me.BusFeeReceiptToolStripMenuItem.Name = "BusFeeReceiptToolStripMenuItem"
        Me.BusFeeReceiptToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.BusFeeReceiptToolStripMenuItem.Text = "Bus Fee Receipt"
        '
        'StudentsToolStripMenuItem6
        '
        Me.StudentsToolStripMenuItem6.Name = "StudentsToolStripMenuItem6"
        Me.StudentsToolStripMenuItem6.Size = New System.Drawing.Size(120, 22)
        Me.StudentsToolStripMenuItem6.Text = "Students"
        '
        'StaffsToolStripMenuItem6
        '
        Me.StaffsToolStripMenuItem6.Name = "StaffsToolStripMenuItem6"
        Me.StaffsToolStripMenuItem6.Size = New System.Drawing.Size(120, 22)
        Me.StaffsToolStripMenuItem6.Text = "Staffs"
        '
        'CourseFeeReceiptToolStripMenuItem
        '
        Me.CourseFeeReceiptToolStripMenuItem.Name = "CourseFeeReceiptToolStripMenuItem"
        Me.CourseFeeReceiptToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.CourseFeeReceiptToolStripMenuItem.Text = "Class Fee Receipt"
        '
        'HostelFeeReceiptToolStripMenuItem
        '
        Me.HostelFeeReceiptToolStripMenuItem.Name = "HostelFeeReceiptToolStripMenuItem"
        Me.HostelFeeReceiptToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.HostelFeeReceiptToolStripMenuItem.Text = "Hostel Fee Receipt"
        '
        'VoucherToolStripMenuItem
        '
        Me.VoucherToolStripMenuItem.Name = "VoucherToolStripMenuItem"
        Me.VoucherToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.VoucherToolStripMenuItem.Text = "Voucher"
        '
        'StudentsToolStripMenuItem7
        '
        Me.StudentsToolStripMenuItem7.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AttendanceToolStripMenuItem1})
        Me.StudentsToolStripMenuItem7.Name = "StudentsToolStripMenuItem7"
        Me.StudentsToolStripMenuItem7.Size = New System.Drawing.Size(199, 22)
        Me.StudentsToolStripMenuItem7.Text = "Students"
        '
        'AttendanceToolStripMenuItem1
        '
        Me.AttendanceToolStripMenuItem1.Name = "AttendanceToolStripMenuItem1"
        Me.AttendanceToolStripMenuItem1.Size = New System.Drawing.Size(135, 22)
        Me.AttendanceToolStripMenuItem1.Text = "Attendance"
        '
        'DueListStudentsToolStripMenuItem
        '
        Me.DueListStudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PartialDueToolStripMenuItem, Me.FullDueToolStripMenuItem})
        Me.DueListStudentsToolStripMenuItem.Name = "DueListStudentsToolStripMenuItem"
        Me.DueListStudentsToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.DueListStudentsToolStripMenuItem.Text = "Fees Due List [Students]"
        '
        'PartialDueToolStripMenuItem
        '
        Me.PartialDueToolStripMenuItem.Name = "PartialDueToolStripMenuItem"
        Me.PartialDueToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.PartialDueToolStripMenuItem.Text = "Partial Due"
        '
        'FullDueToolStripMenuItem
        '
        Me.FullDueToolStripMenuItem.Name = "FullDueToolStripMenuItem"
        Me.FullDueToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.FullDueToolStripMenuItem.Text = "Full Due"
        '
        'DueListStaffsToolStripMenuItem
        '
        Me.DueListStaffsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PartialDueToolStripMenuItem1, Me.FullDueToolStripMenuItem1})
        Me.DueListStaffsToolStripMenuItem.Name = "DueListStaffsToolStripMenuItem"
        Me.DueListStaffsToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.DueListStaffsToolStripMenuItem.Text = "Fees Due List [Staffs]"
        '
        'PartialDueToolStripMenuItem1
        '
        Me.PartialDueToolStripMenuItem1.Name = "PartialDueToolStripMenuItem1"
        Me.PartialDueToolStripMenuItem1.Size = New System.Drawing.Size(131, 22)
        Me.PartialDueToolStripMenuItem1.Text = "Partial Due"
        '
        'FullDueToolStripMenuItem1
        '
        Me.FullDueToolStripMenuItem1.Name = "FullDueToolStripMenuItem1"
        Me.FullDueToolStripMenuItem1.Size = New System.Drawing.Size(131, 22)
        Me.FullDueToolStripMenuItem1.Text = "Full Due"
        '
        'DatabaseToolStripMenuItem1
        '
        Me.DatabaseToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackupToolStripMenuItem, Me.RestoreToolStripMenuItem})
        Me.DatabaseToolStripMenuItem1.Image = CType(resources.GetObject("DatabaseToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.DatabaseToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DatabaseToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.DatabaseToolStripMenuItem1.Name = "DatabaseToolStripMenuItem1"
        Me.DatabaseToolStripMenuItem1.Size = New System.Drawing.Size(67, 69)
        Me.DatabaseToolStripMenuItem1.Text = "Database"
        Me.DatabaseToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'RestoreToolStripMenuItem
        '
        Me.RestoreToolStripMenuItem.Name = "RestoreToolStripMenuItem"
        Me.RestoreToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.RestoreToolStripMenuItem.Text = "Restore"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = CType(resources.GetObject("AboutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AboutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.AboutToolStripMenuItem.Text = "About"
        Me.AboutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogoutToolStripMenuItem1
        '
        Me.LogoutToolStripMenuItem1.Image = CType(resources.GetObject("LogoutToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.LogoutToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogoutToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.LogoutToolStripMenuItem1.Name = "LogoutToolStripMenuItem1"
        Me.LogoutToolStripMenuItem1.Size = New System.Drawing.Size(62, 69)
        Me.LogoutToolStripMenuItem1.Text = "Logout"
        Me.LogoutToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblUserType, Me.ToolStripStatusLabel2, Me.lblUser, Me.ToolStripStatusLabel3, Me.lblDateTime})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 594)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1028, 22)
        Me.StatusStrip1.TabIndex = 7
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(82, 17)
        Me.ToolStripStatusLabel1.Text = "Logged in As :"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.Image = CType(resources.GetObject("lblUserType.Image"), System.Drawing.Image)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(75, 17)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(11, 17)
        Me.ToolStripStatusLabel2.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.ForeColor = System.Drawing.Color.Black
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(65, 17)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(702, 17)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.Black
        Me.lblDateTime.Image = CType(resources.GetObject("lblDateTime.Image"), System.Drawing.Image)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(78, 17)
        Me.lblDateTime.Text = "Date Time"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        '
        'Timer4
        '
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1028, 616)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ES School ERP System 2018 | Developed By E-Solutions PK"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeeInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SchoolInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordPadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSPaintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InstallmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusFeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelFeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DiscountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblUserType As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblDateTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SessionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SchoolTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LibraryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BranchMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SemesterMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DocumentMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelerMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusHoldersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PromotionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InactiveEntryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PayrollToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DepartmentMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesignationMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdvanceEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AtteanceEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubjectMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExamTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExamEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SMSSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmailSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AtteandanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksClassificationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubCategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewspaperMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JournalsAndMagazinesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewspaperEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookIssueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookReturnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksReservationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuotationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccountingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsersRegistrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VoucherToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LibraryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SerialControlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuppliersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JournalsAndMagazinesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewspaperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem16 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem17 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchasedBooksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksIssueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksReservationToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksReturnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileEntryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusHolderToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileEntryToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusHolderToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PayrollToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdvanceEntry1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentAdvanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsAttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsAttendance2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsPayment1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsPayment2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksReservationToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksReturnToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PayrollToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PayrollAdvanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffPaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalarySlipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusFeeReceiptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseFeeReceiptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelFeeReceiptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExpenseMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExpensesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DaybookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneralLedgerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatabaseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents DepartmentMasterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesignationMasterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusHoldersToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TrialBalanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusFeePaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassFeePaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelFeePaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusFeePaymentStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BusFeePaymentStaffsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassFeePaymentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HostelFeePaymentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SQLServerSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DueListStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PartialDueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullDueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DueListStaffsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PartialDueToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullDueToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GradeMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarksEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarksEntryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarksheetLedgerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseDaybookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierLedgerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuppliersToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VoucherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HouseInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExportExcelSheetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsRecordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffsRecordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BooksRecordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IdentityCardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
